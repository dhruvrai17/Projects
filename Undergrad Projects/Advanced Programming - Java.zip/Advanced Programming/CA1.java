
   
package catest1;

import java.util.*;
import java.lang.*;



public class CA1 {                          // Outer Class
    
    
    static class ParaCalc{                  // Static inner class

        public void Calculation()           // Contains the calculation and formula
            {

            int Success = 0;                // Variable to store the success hits of random values in the required region
            double Area;                    // Area under the curve
   /* ********************* Collection ********************* 
           Made two collection,
            1st collection to store Random values for X in the range of 0 to 3.1415
            2nd collection to store Random values for Y in the range of 0 to 9.8590
            
            */
   
            
         Collection c1 = new ArrayList();
         Collection c2 = new ArrayList();

         /* ************************ Generation of random 50000 values     ***************************
           This for loop will generate 50000 values in the range of  0 < X < 3.1415 and 0 < Y < 9.8590
         
         */
         
                    for (int i=0; i<50000; i++)
                    {
                   double start = 0;                            // X range start = 0
                   double end = 3.1415;                         // X range end = 3.1415
                   double random = new Random().nextDouble();   // Random function to generate values in a range of 0 to 3.1415
                   double X = start + (random * (end - start));


                   double start1 = 0;                           // Y range start = 0
                   double end1 = 9.8590;                        // Y range end = 9.8590
                   double random1 = new Random().nextDouble();  // Random function to generate values in a range of 0 to 9.8590
                   double Y = start1 + (random1 * (end1 - start1));

                   c1.add(X);                                   // Adding values of random function to the C1 collection (X Values)
                   c2.add(Y);                                   // Adding values of random function to the C2 collection (Y Values)
                    }

                    /* ************************** Using iterator to loop over the content ************************* */
                     
                     Iterator ir1 = c1.iterator();
                     Iterator ir2 = c2.iterator();

                           while (ir1.hasNext() && ir2.hasNext())  // Hasnext has been used to check and iterate over the content if there is any next element in the ir1 and ir2. 
                          {

                            Object element1 = ir1.next();          // Next() will give the next object of the collection as Object type
                            double X1 = (double) element1;         // Type casted the object to double to use it in the calculation for Area

                            Object element2 = ir2.next(); 
                            double Y1 = (double) element2;

                                                                // Our Parabola equation is [Y = X * X]
                            if( Y1 < X1 * X1 )                  // If our Y is less than X*X, that means the random value hits the required area
                            Success++;                          // Number of success hits. Increments the Success.
                           }


           /* ***************Formula******************* 
           a < x < b - 0 < x < 3.1415
           0 < y < M - 0 < y < 9.8590

           Area = [M(b-a) Counter] / N      Formula

           Area = [9.8590 (3.1415-0)Success]/ 50000

           Area = (30.7290 * Success) / 50000
           */



          Area =  (30.7290 * Success) / 50000;                      // Area calculation

          System.out.println("The Area Under the Curve for Y = X*X between the range of 0 < X < 3.1415 and 0 < Y < 9.8590 using Monte Carlo Approx. = " + Area );   // Print the area.

            }

                      }

                                 }


