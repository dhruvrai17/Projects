

package catest1;


public class CATest1 {
 
    public static void main(String[] args) {
 
 CA1.ParaCalc obj = new CA1.ParaCalc();   // Object for the Static inner class.

 obj.Calculation(); 
   
 /* *************** References ******************* 
    http://www.mathstat.dal.ca/~wrebecca/Simulation.pdf       Formula and steps
    
 http://bytes.com/topic/java/answers/587355-random-numbers-between-number-range-java
 
 http://www.mathcs.emory.edu/~cheung/Courses/170/Syllabus/07/compute-pi.html

         
         */
                                            }
                                            
                    }
