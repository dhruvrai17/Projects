require 'test_helper'

class SoldoutsHelperTest < ActionView::TestCase
end
