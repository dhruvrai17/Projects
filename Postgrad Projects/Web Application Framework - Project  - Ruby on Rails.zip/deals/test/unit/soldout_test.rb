require 'test_helper'

class SoldoutTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
