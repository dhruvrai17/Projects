# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Deals::Application.config.secret_token = 'a8b136b2bbf3773a77f1cb19e855c2fe2f9c852c5749fb9bc99907f30a3877bc3ae71c1bffc9c8f45aabecf5ba98979957ebafb0a3eb28f24678c88617c437fb'
