Rails.application.config.middleware.use OmniAuth::Builder do

  provider :linked_in, '9r6msauxrjxk' , 'tbPMfG9PVD2zAfZc'
end  
