module DealsHelper
end
